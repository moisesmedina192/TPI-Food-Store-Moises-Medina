from entidades.base import Base
from entidades.producto import Producto
from excepciones import DatoInvalidoError
class DetallePedido(Base):
    def __init__(self,cantidad:int,producto:Producto)->None:
        super().__init__(); self.__producto:Producto=producto; self.__precio_unitario:float=producto.precio; self.cantidad=cantidad; self.__subtotal:float=self.cantidad*self.__precio_unitario
    @property
    def producto(self)->Producto:return self.__producto
    @property
    def cantidad(self)->int:return self.__cantidad
    @cantidad.setter
    def cantidad(self,v:int)->None:
        if not isinstance(v,int) or v<=0:raise DatoInvalidoError("La cantidad debe ser un entero mayor que cero.")
        self.__cantidad: int=v
    @property
    def subtotal(self)->float:return self.__subtotal
    def sumar(self,cantidad:int)->None:
        if cantidad<=0:raise DatoInvalidoError("La cantidad debe ser mayor que cero.")
        self.cantidad+=cantidad;self.__subtotal:float=self.cantidad*self.__precio_unitario
    def __str__(self)->str:return f"{self.producto.nombre} x {self.cantidad} = ${self.subtotal:.2f}"
