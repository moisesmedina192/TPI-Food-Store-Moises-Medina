from datetime import date
from entidades.base import Base
from entidades.calculable import Calculable
from entidades.usuario import Usuario
from entidades.producto import Producto
from enums.estado import Estado
from enums.forma_pago import FormaPago
from excepciones import DatoInvalidoError, StockInsuficienteError, OperacionNoPermitidaError
from entidades.detalle_pedido import DetallePedido
class Pedido(Base, Calculable):
    def __init__(self,usuario:Usuario,forma_pago:FormaPago)->None:
        super().__init__()
        if not isinstance(usuario, Usuario):raise DatoInvalidoError("El pedido requiere un usuario válido.")
        if usuario.eliminado:raise DatoInvalidoError("No se puede crear un pedido para un usuario eliminado.")
        if not isinstance(forma_pago,FormaPago):raise DatoInvalidoError("Forma de pago inválida.")
        self.__usuario:Usuario=usuario;self.__fecha:date=date.today();self.__estado:Estado=Estado.PENDIENTE;self.__forma_pago:FormaPago=forma_pago;self.__detalles:list[DetallePedido]=[];self.__total:float=0.0;self.__stock_reintegrado:bool=False
    @property
    def usuario(self)->Usuario:return self.__usuario
    @property
    def fecha(self)->date:return self.__fecha
    @property
    def estado(self)->Estado:return self.__estado
    @property
    def forma_pago(self)->FormaPago:return self.__forma_pago
    @property
    def total(self)->float:return self.__total
    @property
    def detalles(self)->tuple[DetallePedido,...]:return tuple(self.__detalles)
    def agregar_detalle(self,cantidad:int,producto:Producto)->None:
        if self.estado!=Estado.PENDIENTE:raise OperacionNoPermitidaError("Solo se pueden modificar pedidos pendientes.")
        if not isinstance(cantidad,int) or cantidad<=0:raise DatoInvalidoError("La cantidad debe ser un entero mayor que cero.")
        if producto.eliminado or not producto.disponible or producto.categoria.eliminado:raise OperacionNoPermitidaError("El producto no está disponible para nuevos pedidos.")
        existente=self.buscar_detalle_por_producto(producto)
        if cantidad>producto.stock:raise StockInsuficienteError(f"Stock insuficiente para {producto.nombre}. Disponible: {producto.stock}.")
        if existente:existente.sumar(cantidad)
        else:self.__detalles.append(DetallePedido(cantidad,producto))
        producto.stock-=cantidad;self.calcular_total()
    def buscar_detalle_por_producto(self,producto:Producto)->DetallePedido|None:return next((d for d in self.__detalles if d.producto==producto),None)
    def eliminar_detalle_por_producto(self,producto:Producto)->None:
        if self.estado != Estado.PENDIENTE or self.__stock_reintegrado:
            raise OperacionNoPermitidaError("Solo se pueden quitar detalles de un pedido pendiente.")
        detalle=self.buscar_detalle_por_producto(producto)
        if detalle is not None:
            self.__detalles.remove(detalle);producto.stock+=detalle.cantidad;detalle.eliminado=True;self.calcular_total()
    def calcular_total(self)->None:self.__total=sum(d.subtotal for d in self.__detalles if not d.eliminado)
    def cambiar_estado(self,nuevo:Estado)->None:
        permitidos={Estado.PENDIENTE:(Estado.CONFIRMADO,Estado.CANCELADO),Estado.CONFIRMADO:(Estado.TERMINADO,Estado.CANCELADO),Estado.TERMINADO:(),Estado.CANCELADO:()}
        if nuevo not in permitidos[self.estado]:raise OperacionNoPermitidaError("Transición de estado inválida.")
        if nuevo==Estado.CANCELADO:self._reintegrar_stock()
        self.__estado:Estado=nuevo
    def _reintegrar_stock(self)->None:
        if not self.__stock_reintegrado:
            for d in self.__detalles:d.producto.stock+=d.cantidad
            self.__stock_reintegrado=True
    def cambiar_forma_pago(self,forma_pago:FormaPago)->None:
        if not isinstance(forma_pago,FormaPago):raise DatoInvalidoError("Forma de pago inválida.")
        if self.estado in (Estado.TERMINADO,Estado.CANCELADO):raise OperacionNoPermitidaError("No se puede cambiar el pago de un pedido cerrado.")
        self.__forma_pago:FormaPago=forma_pago
    def eliminar(self)->None:
        if self.estado not in (Estado.TERMINADO,Estado.CANCELADO):self._reintegrar_stock()
        for detalle in self.__detalles:detalle.eliminado=True
        self.eliminado=True
    def __str__(self)->str:return f"[{self.id}] {self.usuario.nombre} {self.usuario.apellido} | {self.estado.value} | {self.forma_pago.value} | ${self.total:.2f} | {self.fecha}"
