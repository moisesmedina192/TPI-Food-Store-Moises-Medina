from entidades.base import Base
from enums.rol import Rol
from excepciones import DatoInvalidoError
class Usuario(Base):
    def __init__(self,nombre:str,apellido:str,mail:str,celular:str,contrasenia:str,rol:Rol)->None:
        super().__init__(); self.nombre=nombre; self.apellido=apellido; self.mail=mail; self.celular=celular; self.rol=rol; self.__contrasenia=""; self.cambiar_contrasenia(contrasenia)
    @property
    def nombre(self)->str:return self.__nombre
    @nombre.setter
    def nombre(self,v:str)->None:
        if not v.strip():raise DatoInvalidoError("El nombre no puede estar vacío.")
        self.__nombre: str=v.strip()
    @property
    def apellido(self)->str:return self.__apellido
    @apellido.setter
    def apellido(self,v:str)->None:
        if not v.strip():raise DatoInvalidoError("El apellido no puede estar vacío.")
        self.__apellido: str=v.strip()
    @property
    def mail(self)->str:return self.__mail
    @mail.setter
    def mail(self,v:str)->None:
        limpio=v.strip().lower()
        if not limpio or "@" not in limpio or "." not in limpio.split("@")[-1]:raise DatoInvalidoError("El mail debe tener un formato válido.")
        self.__mail: str=limpio
    @property
    def celular(self)->str:return self.__celular
    @celular.setter
    def celular(self,v:str)->None:
        if not v.strip():raise DatoInvalidoError("El celular no puede estar vacío.")
        self.__celular: str=v.strip()
    @property
    def rol(self)->Rol:return self.__rol
    @rol.setter
    def rol(self,v:Rol)->None:
        if not isinstance(v,Rol):raise DatoInvalidoError("Rol inválido.")
        self.__rol: Rol=v
    def verificar_contrasenia(self,contrasenia:str)->bool:return self.__contrasenia==contrasenia
    def cambiar_contrasenia(self,contrasenia:str)->None:
        if not contrasenia:raise DatoInvalidoError("La contraseña no puede estar vacía.")
        self.__contrasenia: str=contrasenia
    def __str__(self)->str:return f"[{self.id}] {self.nombre} {self.apellido} | {self.mail} | {self.celular} | {self.rol.value}"
