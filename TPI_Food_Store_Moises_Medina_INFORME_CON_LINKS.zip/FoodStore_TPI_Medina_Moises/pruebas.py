"""Pruebas automatizadas del modelo y los servicios de Food Store."""
import unittest
from main import crear_servicios, cargar_datos
from enums.rol import Rol
from enums.forma_pago import FormaPago
from enums.estado import Estado
from excepciones import (DuplicadoError, PrecioInvalidoError, StockInsuficienteError,
                         CredencialesInvalidasError, OperacionNoPermitidaError,
                         DatoInvalidoError)

class PruebasFoodStore(unittest.TestCase):
    def setUp(self) -> None:
        self.s = crear_servicios(); cargar_datos(self.s)
        self.admin = self.s["usuarios"].listar()[0]
        self.cliente = self.s["usuarios"].listar()[1]
        self.producto = self.s["productos"].listar()[0]

    def test_login_admin_valido(self) -> None:
        self.assertEqual(self.s["usuarios"].autenticar("admin@foodstore.com", "admin123").rol, Rol.ADMIN)
    def test_login_cliente_valido(self) -> None:
        self.assertEqual(self.s["usuarios"].autenticar("cliente@foodstore.com", "cliente123").rol, Rol.USUARIO)
    def test_login_invalido(self) -> None:
        with self.assertRaises(CredencialesInvalidasError): self.s["usuarios"].autenticar("admin@foodstore.com", "incorrecta")
    def test_usuario_mail_duplicado(self) -> None:
        with self.assertRaises(DuplicadoError): self.s["usuarios"].crear("Otro", "Usuario", "ADMIN@foodstore.com", "123", "clave", Rol.USUARIO)
    def test_usuario_eliminado_no_inicia_sesion(self) -> None:
        self.s["usuarios"].eliminar(self.cliente.id)
        with self.assertRaises(CredencialesInvalidasError): self.s["usuarios"].autenticar("cliente@foodstore.com", "cliente123")
    def test_categoria_duplicada_sin_distinguir_mayusculas(self) -> None:
        with self.assertRaises(DuplicadoError): self.s["categorias"].crear("bebidas", "otra descripción")
    def test_categoria_con_producto_activo_no_se_elimina(self) -> None:
        categoria = self.producto.categoria
        with self.assertRaises(OperacionNoPermitidaError): self.s["categorias"].eliminar(categoria.id, self.s["productos"].listar())
    def test_precio_negativo_rechazado(self) -> None:
        with self.assertRaises(PrecioInvalidoError): self.s["productos"].crear("Error", -1, "desc", 1, "", True, self.producto.categoria)
    def test_stock_negativo_rechazado(self) -> None:
        with self.assertRaises(DatoInvalidoError): self.s["productos"].crear("Error", 1, "desc", -1, "", True, self.producto.categoria)
    def test_total_y_descuento_de_stock(self) -> None:
        pedido = self.s["pedidos"].crear_con_detalles(self.cliente, FormaPago.EFECTIVO, [(self.producto, 2)])
        self.assertEqual(pedido.total, 2 * self.producto.precio); self.assertEqual(self.producto.stock, 8)
    def test_agregar_mismo_producto_suma_cantidad(self) -> None:
        pedido = self.s["pedidos"].crear(self.cliente, FormaPago.EFECTIVO)
        pedido.agregar_detalle(1, self.producto); pedido.agregar_detalle(2, self.producto)
        self.assertEqual(len(pedido.detalles), 1); self.assertEqual(pedido.detalles[0].cantidad, 3)
    def test_precio_del_detalle_se_congela(self) -> None:
        pedido = self.s["pedidos"].crear(self.cliente, FormaPago.EFECTIVO); pedido.agregar_detalle(2, self.producto)
        subtotal = pedido.detalles[0].subtotal; self.producto.precio += 500
        self.assertEqual(pedido.detalles[0].subtotal, subtotal)
    def test_stock_insuficiente_no_descuenta(self) -> None:
        stock = self.producto.stock
        with self.assertRaises(StockInsuficienteError): self.s["pedidos"].crear_con_detalles(self.cliente, FormaPago.EFECTIVO, [(self.producto, stock+1)])
        self.assertEqual(self.producto.stock, stock); self.assertEqual(self.s["pedidos"].listar(), [])
    def test_creacion_fallida_revierte_stock_previo(self) -> None:
        stock = self.producto.stock
        with self.assertRaises(StockInsuficienteError): self.s["pedidos"].crear_con_detalles(self.cliente, FormaPago.EFECTIVO, [(self.producto, 2), (self.producto, 999)])
        self.assertEqual(self.producto.stock, stock); self.assertEqual(self.s["pedidos"].listar(), [])
    def test_cancelar_devuelve_stock_una_sola_vez(self) -> None:
        stock = self.producto.stock; pedido = self.s["pedidos"].crear_con_detalles(self.cliente, FormaPago.EFECTIVO, [(self.producto, 2)])
        pedido.cambiar_estado(Estado.CANCELADO); self.assertEqual(self.producto.stock, stock)
        with self.assertRaises(OperacionNoPermitidaError): pedido.cambiar_estado(Estado.PENDIENTE)
        self.assertEqual(self.producto.stock, stock)
    def test_transicion_de_estado_valida(self) -> None:
        pedido = self.s["pedidos"].crear_con_detalles(self.cliente, FormaPago.EFECTIVO, [(self.producto, 1)])
        pedido.cambiar_estado(Estado.CONFIRMADO); pedido.cambiar_estado(Estado.TERMINADO)
        self.assertEqual(pedido.estado, Estado.TERMINADO)
    def test_no_puede_eliminarse_a_si_mismo(self) -> None:
        with self.assertRaises(OperacionNoPermitidaError): self.s["usuarios"].eliminar(self.admin.id, self.admin)
    def test_cliente_solo_ve_productos_disponibles_con_stock(self) -> None:
        self.producto.disponible = False
        self.assertNotIn(self.producto, self.s["productos"].listar_cliente())
    def test_baja_logica_categoria(self) -> None:
        c = self.s["categorias"].crear("Postres", "Dulces")
        self.s["categorias"].eliminar(c.id, self.s["productos"].listar())
        self.assertNotIn(c, self.s["categorias"].listar()); self.assertTrue(c.eliminado)

if __name__ == "__main__": unittest.main(verbosity=2)
