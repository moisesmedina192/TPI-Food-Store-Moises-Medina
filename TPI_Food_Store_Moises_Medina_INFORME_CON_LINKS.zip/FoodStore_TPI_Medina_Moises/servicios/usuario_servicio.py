from servicios.base_servicio import BaseServicio
from entidades.usuario import Usuario
from enums.rol import Rol
from excepciones import DuplicadoError,CredencialesInvalidasError,OperacionNoPermitidaError
class UsuarioServicio(BaseServicio[Usuario]):
    def crear(self,nombre:str,apellido:str,mail:str,celular:str,contrasenia:str,rol:Rol)->Usuario:
        if any(u.mail==mail.strip().lower() for u in self._elementos):raise DuplicadoError("Ya existe un usuario con ese mail.")
        usuario=Usuario(nombre,apellido,mail,celular,contrasenia,rol);self._elementos.append(usuario);return usuario
    def editar(self,identificador:int,nombre:str,apellido:str,mail:str,celular:str,rol:Rol,contrasenia:str='')->Usuario:
        u=self.buscar_por_id(identificador)
        from excepciones import DatoInvalidoError
        limpio=mail.strip().lower()
        if not nombre.strip() or not apellido.strip() or not celular.strip():raise DatoInvalidoError("Nombre, apellido y celular son obligatorios.")
        if "@" not in limpio or "." not in limpio.split("@")[-1]:raise DatoInvalidoError("El mail debe tener un formato válido.")
        if not isinstance(rol,Rol):raise DatoInvalidoError("Rol inválido.")
        if any(x.id!=u.id and x.mail==limpio for x in self._elementos):raise DuplicadoError("Ya existe un usuario con ese mail.")
        u.nombre=nombre;u.apellido=apellido;u.mail=mail;u.celular=celular;u.rol=rol
        if contrasenia:u.cambiar_contrasenia(contrasenia)
        return u
    def autenticar(self,mail:str,contrasenia:str)->Usuario:
        for u in self._elementos:
            if u.mail==mail.strip().lower() and not u.eliminado and u.verificar_contrasenia(contrasenia):return u
        raise CredencialesInvalidasError("Mail o contraseña incorrectos")
    def eliminar(self,identificador:int,sesion:Usuario|None=None)->None:
        u=self.buscar_por_id(identificador)
        if sesion is not None and u==sesion:raise OperacionNoPermitidaError("Un administrador no puede eliminarse a sí mismo durante su sesión.")
        u.eliminado=True
