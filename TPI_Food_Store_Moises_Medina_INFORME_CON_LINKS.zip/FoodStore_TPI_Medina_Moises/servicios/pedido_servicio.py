from servicios.base_servicio import BaseServicio
from entidades.pedido import Pedido
from entidades.usuario import Usuario
from entidades.producto import Producto
from enums.forma_pago import FormaPago
from enums.estado import Estado
from excepciones import DatoInvalidoError
class PedidoServicio(BaseServicio[Pedido]):
    def crear(self,usuario:Usuario,forma_pago:FormaPago)->Pedido:
        return Pedido(usuario,forma_pago)
    def guardar(self,pedido:Pedido)->Pedido:
        if not pedido.detalles:raise DatoInvalidoError("El pedido debe contener al menos un producto.")
        self._elementos.append(pedido);return pedido
    def crear_con_detalles(self,usuario:Usuario,forma_pago:FormaPago,items:list[tuple[Producto,int]])->Pedido:
        pedido=Pedido(usuario,forma_pago);modificados:list[tuple[Producto,int]]=[]
        try:
            for producto,cantidad in items:
                pedido.agregar_detalle(cantidad,producto);modificados.append((producto,cantidad))
            if not pedido.detalles:raise DatoInvalidoError("El pedido debe contener al menos un producto.")
        except Exception:
            for producto,cantidad in modificados:producto.stock+=cantidad
            raise
        self._elementos.append(pedido);return pedido
    def pedidos_de_usuario(self,usuario:Usuario)->list[Pedido]:return [p for p in self.listar() if p.usuario==usuario]
    def cambiar_estado(self,identificador:int,estado:Estado)->Pedido:
        pedido=self.buscar_por_id(identificador);pedido.cambiar_estado(estado);return pedido
    def eliminar(self,identificador:int)->None:self.buscar_por_id(identificador).eliminar()
