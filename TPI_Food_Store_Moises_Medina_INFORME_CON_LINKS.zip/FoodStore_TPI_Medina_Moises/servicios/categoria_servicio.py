from servicios.base_servicio import BaseServicio
from entidades.categoria import Categoria
from entidades.producto import Producto
from excepciones import DuplicadoError,OperacionNoPermitidaError
class CategoriaServicio(BaseServicio[Categoria]):
    def crear(self,nombre:str,descripcion:str)->Categoria:
        if any(c.nombre.casefold()==nombre.strip().casefold() and not c.eliminado for c in self._elementos):raise DuplicadoError("Ya existe una categoría con ese nombre.")
        categoria=Categoria(nombre,descripcion);self._elementos.append(categoria);return categoria
    def editar(self,identificador:int,nombre:str,descripcion:str)->Categoria:
        c=self.buscar_por_id(identificador)
        if not nombre.strip() or not descripcion.strip():
            from excepciones import DatoInvalidoError
            raise DatoInvalidoError("El nombre y la descripción no pueden estar vacíos.")
        if any(x.id!=identificador and x.nombre.casefold()==nombre.strip().casefold() and not x.eliminado for x in self._elementos):raise DuplicadoError("Ya existe una categoría con ese nombre.")
        c.nombre=nombre;c.descripcion=descripcion;return c
    def eliminar(self,identificador:int,productos:list[Producto]|None=None)->None:
        c=self.buscar_por_id(identificador);activos=[p for p in (productos or []) if not p.eliminado and p.categoria==c]
        if activos:raise OperacionNoPermitidaError(f"No se puede eliminar: la categoría tiene {len(activos)} producto(s) activo(s).")
        c.eliminado=True
