from servicios.base_servicio import BaseServicio
from entidades.producto import Producto
from entidades.categoria import Categoria
class ProductoServicio(BaseServicio[Producto]):
    def crear(self,nombre:str,precio:float,descripcion:str,stock:int,imagen:str,disponible:bool,categoria:Categoria)->Producto:
        producto=Producto(nombre,precio,descripcion,stock,imagen,disponible,categoria);self._elementos.append(producto);return producto
    def editar(self,identificador:int,nombre:str,precio:float,descripcion:str,stock:int,imagen:str,disponible:bool,categoria:Categoria)->Producto:
        p=self.buscar_por_id(identificador)
        # Validar todos los campos antes de mutar para evitar actualizaciones parciales.
        from excepciones import DatoInvalidoError, PrecioInvalidoError
        if not nombre.strip() or not descripcion.strip():raise DatoInvalidoError("Nombre y descripción son obligatorios.")
        if precio < 0:raise PrecioInvalidoError("El precio no puede ser negativo.")
        if stock < 0:raise DatoInvalidoError("El stock no puede ser negativo.")
        if categoria.eliminado:raise DatoInvalidoError("La categoría está eliminada.")
        p.nombre=nombre;p.precio=precio;p.descripcion=descripcion;p.stock=stock;p.imagen=imagen;p.disponible=disponible;p.categoria=categoria;return p
    def listar_cliente(self)->list[Producto]:return [p for p in self.listar() if p.disponible and p.stock>0 and not p.categoria.eliminado]
