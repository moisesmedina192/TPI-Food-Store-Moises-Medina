"""Punto de entrada de Food Store. Los servicios viven durante la sesión del programa."""
from typing import Any
from servicios.categoria_servicio import CategoriaServicio
from servicios.producto_servicio import ProductoServicio
from servicios.usuario_servicio import UsuarioServicio
from servicios.pedido_servicio import PedidoServicio
from consola.fabrica_menu import crear_menu
from enums.rol import Rol
from enums.forma_pago import FormaPago
from excepciones import CredencialesInvalidasError

def crear_servicios() -> dict[str, Any]:
    return {"categorias": CategoriaServicio(), "productos": ProductoServicio(), "usuarios": UsuarioServicio(), "pedidos": PedidoServicio()}

def cargar_datos(servicios: dict[str, Any]) -> None:
    """Carga cuentas y catálogo de ejemplo para poder probar el sistema."""
    servicios["usuarios"].crear("Ana", "Pérez", "admin@foodstore.com", "2610000000", "admin123", Rol.ADMIN)
    servicios["usuarios"].crear("Juan", "Gómez", "cliente@foodstore.com", "2611111111", "cliente123", Rol.USUARIO)
    bebidas = servicios["categorias"].crear("Bebidas", "Bebidas frías y calientes")
    comidas = servicios["categorias"].crear("Comidas", "Platos preparados")
    servicios["productos"].crear("Agua mineral", 1200.0, "Botella de 500 ml", 10, "", True, bebidas)
    servicios["productos"].crear("Hamburguesa clásica", 4500.0, "Hamburguesa con queso", 5, "", True, comidas)
    servicios["productos"].crear("Papas fritas", 2200.0, "Porción mediana", 8, "", True, comidas)

def main() -> None:
    servicios = crear_servicios()
    cargar_datos(servicios)
    while True:
        intentos = 0
        usuario = None
        while intentos < 3:
            print("\n=== FOOD STORE – INICIO DE SESIÓN ===")
            mail = input("Mail: ").strip()
            contrasenia = input("Contraseña: ")
            try:
                usuario = servicios["usuarios"].autenticar(mail, contrasenia)
                break
            except CredencialesInvalidasError:
                intentos += 1
                print("Mail o contraseña incorrectos")
        if usuario is None:
            print("Se agotaron los 3 intentos. El programa finalizará.")
            return
        print(f"Bienvenido/a {usuario.nombre} {usuario.apellido} [{usuario.rol.value}]")
        # True significa cerrar sesión; False significa salir del programa.
        cerrar_sesion = crear_menu(usuario, servicios).mostrar()
        if not cerrar_sesion:
            print("Hasta luego.")
            return

if __name__ == "__main__":
    main()
