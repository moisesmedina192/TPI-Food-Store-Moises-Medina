from abc import ABC,abstractmethod
from entidades.usuario import Usuario
class Menu(ABC):
    def __init__(self,usuario:Usuario,servicios:dict[str,object])->None:self._usuario=usuario;self._servicios=servicios
    @abstractmethod
    def mostrar(self)->bool:...
