from typing import Callable, TypeVar
from excepciones import FoodStoreError
T=TypeVar('T')
def texto(mensaje:str, permitir_vacio:bool=False)->str:
    while True:
        valor=input(mensaje).strip()
        if valor or permitir_vacio:return valor
        print("El texto no puede estar vacío.")
def entero(mensaje:str, minimo:int|None=None)->int:
    while True:
        try:
            valor=int(input(mensaje))
            if minimo is not None and valor<minimo:print(f"Ingrese un número mayor o igual a {minimo}.");continue
            return valor
        except ValueError:print("Ingrese un número entero válido.")
def decimal(mensaje:str, minimo:float|None=None)->float:
    while True:
        try:
            valor=float(input(mensaje).replace(',','.'))
            if minimo is not None and valor<minimo:print(f"Ingrese un número mayor o igual a {minimo}.");continue
            return valor
        except ValueError:print("Ingrese un número válido.")
def si_no(mensaje:str)->bool:
    while True:
        v=input(mensaje+" (S/N): ").strip().upper()
        if v in ("S","N"):return v=="S"
        print("Responda S o N.")
def elegir_enum(mensaje:str, enum_cls:type[T])->T:
    opciones=list(enum_cls)
    for i,opcion in enumerate(opciones,1):print(f"{i}. {opcion.value}")
    while True:
        n=entero(mensaje,1)
        if n<=len(opciones):return opciones[n-1]
        print("Opción fuera de rango.")
def ejecutar(accion:Callable[[],object])->None:
    try:
        resultado=accion()
        if resultado is not None:print("Operación realizada:",resultado)
    except FoodStoreError as e:print("Error:",e)
    except ValueError as e:print("Dato inválido:",e)
