from consola.menu import Menu
from consola.lectura import texto,entero,decimal,si_no,elegir_enum,ejecutar
from enums.rol import Rol
from enums.estado import Estado
from enums.forma_pago import FormaPago
from excepciones import FoodStoreError
class MenuAdministrador(Menu):
    def mostrar(self)->bool:
        while True:
            print(f"\n=== FOOD STORE – ADMINISTRADOR ({self._usuario.nombre} {self._usuario.apellido}) ===")
            print("1. Categorías  2. Productos  3. Usuarios  4. Pedidos  5. Cerrar sesión  0. Salir")
            op=input("Seleccione: ").strip()
            if op=="1":self._categorias()
            elif op=="2":self._productos()
            elif op=="3":self._usuarios()
            elif op=="4":self._pedidos()
            elif op=="5":return True
            elif op=="0":return False
            else:print("Opción inválida.")
    def _categorias(self)->None:
        s=self._servicios["categorias"];productos=self._servicios["productos"]
        while True:
            print("\n--- CATEGORÍAS ---\n1. Listar  2. Crear  3. Editar  4. Eliminar  0. Volver")
            op=input("Seleccione: ").strip()
            if op=="1":
                items=s.listar();[print(x) for x in items] if items else print("No hay categorías cargadas.")
            elif op=="2":ejecutar(lambda:s.crear(texto("Nombre: "),texto("Descripción: ")))
            elif op=="3":
                [print(x) for x in s.listar()];i=entero("ID a editar: ",1)
                ejecutar(lambda:s.editar(i,texto("Nuevo nombre (Enter conserva): ",True) or s.buscar_por_id(i).nombre,texto("Nueva descripción (Enter conserva): ",True) or s.buscar_por_id(i).descripcion))
            elif op=="4":
                [print(x) for x in s.listar()];i=entero("ID a eliminar: ",1)
                if si_no("¿Confirma la baja lógica?"):ejecutar(lambda:s.eliminar(i,productos.listar()))
            elif op=="0":return
            else:print("Opción inválida.")
    def _productos(self)->None:
        s=self._servicios["productos"];cs=self._servicios["categorias"]
        while True:
            print("\n--- PRODUCTOS ---\n1. Listar  2. Crear  3. Editar  4. Eliminar  0. Volver")
            op=input("Seleccione: ").strip()
            if op=="1":
                items=s.listar();[print(x) for x in items] if items else print("No hay productos cargados.")
            elif op in ("2","3"):
                p=None;i=0
                if op=="3":
                    [print(x) for x in s.listar()];i=entero("ID a editar: ",1)
                    try:p=s.buscar_por_id(i)
                    except FoodStoreError as e:print("Error:",e);continue
                cats=cs.listar();[print(x) for x in cats]
                if not cats:print("Primero debe crear una categoría.");continue
                try:
                    nombre=(input(f"Nombre [{p.nombre}]: ").strip() or p.nombre) if p else texto("Nombre: ")
                    descripcion=(input(f"Descripción [{p.descripcion}]: ").strip() or p.descripcion) if p else texto("Descripción: ")
                    if p:
                        raw=input(f"Precio [{p.precio}]: ").strip();precio=float(raw.replace(',','.')) if raw else p.precio
                        raw=input(f"Stock [{p.stock}]: ").strip();stock=int(raw) if raw else p.stock
                        imagen=input(f"Imagen/ruta [{p.imagen}]: ").strip() or p.imagen
                        raw=input(f"Disponible S/N [{'S' if p.disponible else 'N'}]: ").strip().upper();disponible=(raw=="S") if raw in ("S","N") else p.disponible
                        raw=input(f"ID categoría [{p.categoria.id}]: ").strip();cat_id=int(raw) if raw else p.categoria.id
                    else:
                        precio=decimal("Precio: ",0);stock=entero("Stock: ",0);imagen=input("Imagen/ruta (opcional): ").strip();disponible=si_no("¿Disponible")
                        cat_id=entero("ID de categoría: ",1)
                    cat=cs.buscar_por_id(cat_id)
                    if p:ejecutar(lambda:s.editar(i,nombre,precio,descripcion,stock,imagen,disponible,cat))
                    else:ejecutar(lambda:s.crear(nombre,precio,descripcion,stock,imagen,disponible,cat))
                except (ValueError,FoodStoreError) as e:print("Error:",e)
            elif op=="4":
                [print(x) for x in s.listar()];i=entero("ID a eliminar: ",1)
                if si_no("¿Confirma la baja lógica?"):ejecutar(lambda:s.eliminar(i))
            elif op=="0":return
            else:print("Opción inválida.")
    def _usuarios(self)->None:
        s=self._servicios["usuarios"]
        while True:
            print("\n--- USUARIOS ---\n1. Listar  2. Crear  3. Editar  4. Eliminar  0. Volver")
            op=input("Seleccione: ").strip()
            if op=="1":
                items=s.listar();[print(x) for x in items] if items else print("No hay usuarios cargados.")
            elif op in ("2","3"):
                if op=="3":
                    [print(x) for x in s.listar()];i=entero("ID a editar: ",1)
                    try:u=s.buscar_por_id(i)
                    except FoodStoreError as e:print("Error:",e);continue
                else:u=None;i=0
                try:
                    nombre=texto("Nombre"+(f" [{u.nombre}]" if u else "")+": ",bool(u)) or (u.nombre if u else "")
                    apellido=texto("Apellido"+(f" [{u.apellido}]" if u else "")+": ",bool(u)) or (u.apellido if u else "")
                    mail=texto("Mail"+(f" [{u.mail}]" if u else "")+": ",bool(u)) or (u.mail if u else "")
                    celular=texto("Celular"+(f" [{u.celular}]" if u else "")+": ",bool(u)) or (u.celular if u else "")
                    if u:
                        rol=elegir_enum("Rol (Enter conserva no disponible; elegir número): ",Rol) if si_no("¿Cambiar rol?") else u.rol
                        clave=input("Nueva contraseña (Enter conserva): ")
                        ejecutar(lambda:s.editar(i,nombre,apellido,mail,celular,rol,clave))
                    else:
                        clave=texto("Contraseña: ");rol=elegir_enum("Seleccione rol: ",Rol)
                        ejecutar(lambda:s.crear(nombre,apellido,mail,celular,clave,rol))
                except FoodStoreError as e:print("Error:",e)
            elif op=="4":
                [print(x) for x in s.listar()];i=entero("ID a eliminar: ",1)
                if si_no("¿Confirma la baja lógica?"):ejecutar(lambda:s.eliminar(i,self._usuario))
            elif op=="0":return
            else:print("Opción inválida.")
    def _pedidos(self)->None:
        s=self._servicios["pedidos"];us=self._servicios["usuarios"];ps=self._servicios["productos"]
        while True:
            print("\n--- PEDIDOS ---\n1. Listar  2. Crear  3. Cambiar estado/pago  4. Eliminar  5. Ver detalles  0. Volver")
            op=input("Seleccione: ").strip()
            if op=="1":
                items=s.listar();[print(x) for x in items] if items else print("No hay pedidos cargados.")
            elif op=="2":
                [print(x) for x in us.listar()];uid=entero("ID de usuario: ",1)
                try:u=us.buscar_por_id(uid)
                except FoodStoreError as e:print("Error:",e);continue
                pago=elegir_enum("Forma de pago: ",FormaPago);items=[]
                while True:
                    [print(x) for x in ps.listar()]
                    pid=entero("ID de producto (0 para finalizar): ",0)
                    if pid==0:break
                    try:p=ps.buscar_por_id(pid);cant=entero("Cantidad: ",1);items.append((p,cant))
                    except FoodStoreError as e:print("Error:",e)
                ejecutar(lambda:s.crear_con_detalles(u,pago,items))
            elif op=="3":
                [print(x) for x in s.listar()];i=entero("ID del pedido: ",1)
                try:p=s.buscar_por_id(i)
                except FoodStoreError as e:print("Error:",e);continue
                if si_no("¿Cambiar estado?"):
                    estado=elegir_enum("Nuevo estado: ",Estado);ejecutar(lambda:s.cambiar_estado(i,estado))
                if si_no("¿Cambiar forma de pago?"):
                    pago=elegir_enum("Nueva forma de pago: ",FormaPago);ejecutar(lambda:p.cambiar_forma_pago(pago))
            elif op=="4":
                [print(x) for x in s.listar()];i=entero("ID a eliminar: ",1)
                if si_no("¿Confirma eliminar (baja lógica)?"):ejecutar(lambda:s.eliminar(i))
            elif op=="5":
                [print(x) for x in s.listar()];i=entero("ID del pedido: ",1)
                try:p=s.buscar_por_id(i);[print(" -",d) for d in p.detalles];print(f"Total: ${p.total:.2f}")
                except FoodStoreError as e:print("Error:",e)
            elif op=="0":return
            else:print("Opción inválida.")
