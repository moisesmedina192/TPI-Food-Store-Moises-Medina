"""Menú y operaciones disponibles para el usuario cliente."""
from consola.menu import Menu
from consola.lectura import entero, elegir_enum
from enums.forma_pago import FormaPago
from enums.estado import Estado
from excepciones import FoodStoreError


class MenuCliente(Menu):
    def mostrar(self) -> bool:
        while True:
            print(f"\n=== FOOD STORE – CLIENTE ({self._usuario.nombre} {self._usuario.apellido}) ===")
            print("1. Ver categorías  2. Ver productos disponibles  3. Pedidos  4. Mis datos  5. Cerrar sesión  0. Salir")
            op = input("Seleccione: ").strip()
            if op == "1":
                items = self._servicios["categorias"].listar()
                [print(x) for x in items] if items else print("No hay categorías cargadas.")
            elif op == "2":
                self._mostrar_productos()
            elif op == "3":
                self._menu_pedidos()
            elif op == "4":
                print(self._usuario)
            elif op == "5":
                return True
            elif op == "0":
                return False
            else:
                print("Opción inválida.")

    def _mostrar_productos(self) -> None:
        items = self._servicios["productos"].listar_cliente()
        [print(x) for x in items] if items else print("No hay productos disponibles con stock.")

    def _menu_pedidos(self) -> None:
        while True:
            print("\n--- PEDIDOS ---")
            print("1. Crear pedido  2. Ver mis pedidos / cancelar  0. Volver")
            op = input("Seleccione: ").strip()
            if op == "1":
                self._crear_pedido()
            elif op == "2":
                self._ver_pedidos()
            elif op == "0":
                return
            else:
                print("Opción inválida.")

    def _crear_pedido(self) -> None:
        productos = self._servicios["productos"].listar_cliente()
        if not productos:
            print("No hay productos disponibles con stock.")
            return
        print("\nProductos disponibles:")
        for producto in productos:
            print(producto)
        items = []
        while True:
            try:
                identificador = entero("ID del producto (0 para terminar): ", 0)
                if identificador == 0:
                    break
                producto = next((p for p in productos if p.id == identificador), None)
                if producto is None:
                    print("El producto no existe o no está disponible.")
                    continue
                cantidad = entero("Cantidad: ", 1)
                items.append((producto, cantidad))
                if input("¿Agregar otro producto? (S/N): ").strip().upper() != "S":
                    break
            except (ValueError, StopIteration) as error:
                print("Dato inválido:", error)
        if not items:
            print("No se creó el pedido porque no se seleccionaron productos.")
            return
        forma_pago = elegir_enum("Forma de pago: ", FormaPago)
        try:
            pedido = self._servicios["pedidos"].crear_con_detalles(self._usuario, forma_pago, items)
            print("Pedido creado correctamente:")
            print(pedido)
            for detalle in pedido.detalles:
                print(" -", detalle)
            print(f"Total: ${pedido.total:.2f}")
        except FoodStoreError as error:
            print("No se pudo crear el pedido:", error)

    def _ver_pedidos(self) -> None:
        pedidos = self._servicios["pedidos"].pedidos_de_usuario(self._usuario)
        if not pedidos:
            print("No tenés pedidos cargados.")
            return
        for pedido in pedidos:
            print(pedido)
        if input("¿Ver detalles o cancelar un pedido? (S/N): ").strip().upper() != "S":
            return
        try:
            identificador = entero("ID del pedido: ", 1)
            pedido = next(p for p in pedidos if p.id == identificador)
            for detalle in pedido.detalles:
                if not detalle.eliminado:
                    print(" -", detalle)
            print(f"Total: ${pedido.total:.2f}")
            if pedido.estado in (Estado.PENDIENTE, Estado.CONFIRMADO):
                if input("¿Cancelar este pedido? (S/N): ").strip().upper() == "S":
                    pedido.cambiar_estado(Estado.CANCELADO)
                    print("Pedido cancelado. El stock fue reintegrado.")
        except StopIteration:
            print("El pedido no existe o no pertenece a tu cuenta.")
        except (FoodStoreError, ValueError) as error:
            print("No se pudo procesar la operación:", error)
