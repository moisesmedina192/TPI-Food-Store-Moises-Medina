from consola.menu import Menu
from consola.menu_administrador import MenuAdministrador
from consola.menu_cliente import MenuCliente
from entidades.usuario import Usuario
from enums.rol import Rol
def crear_menu(usuario:Usuario,servicios:dict[str,object])->Menu:
    if usuario.rol==Rol.ADMIN:return MenuAdministrador(usuario,servicios)
    return MenuCliente(usuario,servicios)
