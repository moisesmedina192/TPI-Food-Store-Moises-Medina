# Food Store — Trabajo Práctico Integrador de Programación II

Sistema de consola desarrollado en Python para gestionar categorías, productos, usuarios y pedidos aplicando Programación Orientada a Objetos (POO). Los datos se guardan en colecciones en memoria durante la ejecución; al cerrar el programa se reinician, tal como solicita la consigna.

## Requisitos

- Python 3.12 o superior.
- No requiere instalar paquetes externos: utiliza la biblioteca estándar.
- Ejecutar los comandos desde la carpeta raíz del proyecto.

## Cómo ejecutar

```bash
python main.py
```

## Credenciales de demostración

| Rol | Mail | Contraseña |
|---|---|---|
| Administrador | `admin@foodstore.com` | `admin123` |
| Cliente | `cliente@foodstore.com` | `cliente123` |

El inicio de sesión permite hasta tres intentos. El menú cambia según el rol. El administrador puede gestionar las entidades; el cliente puede consultar el catálogo, crear pedidos, revisar/cancelar sus propios pedidos y consultar sus datos. En el menú del cliente, la opción **3. Pedidos** abre las opciones para crear un pedido o ver/cancelar uno existente.

## Ejecutar las pruebas

```bash
python pruebas.py
```

Las pruebas verifican autenticación, duplicados, validaciones de precio y stock, creación de pedidos, cálculo de subtotales y totales, falta de stock, recuperación del stock al cancelar, transiciones de estado y restricciones de eliminación.

## Estructura

```text
FoodStore_TPI_Medina_Moises/
├── main.py
├── pruebas.py
├── README.md
├── informe.pdf
├── entidades/       # Base, Categoria, Producto, Usuario, Pedido, DetallePedido, Calculable
├── enums/           # Rol, Estado, FormaPago
├── excepciones/     # Excepciones propias del dominio
├── servicios/       # Colecciones y reglas de negocio
└── consola/         # Menús por rol y lectura validada
```

## Reglas implementadas

- Identificadores automáticos compartidos, fecha de creación y bajas lógicas.
- Atributos encapsulados mediante properties y validaciones.
- Mail de usuario y nombre de categoría únicos.
- Precios y stock no negativos; cantidad de pedido positiva.
- Categorías con productos activos no se pueden eliminar.
- Pedidos con detalles compuestos dentro del pedido, cálculo del total mediante `Calculable` y precio unitario tomado al crear el detalle.
- El stock se descuenta al crear un pedido válido y se revierte si falla la creación o si se cancela/elimina un pedido no terminado.
- Transiciones de estado restringidas según la consigna.
- Menús separados por rol mediante polimorfismo.

## Enlaces para la entrega

- **Repositorio GitHub:** https://github.com/moisesmedina192/TPI-Food-Store-Moises-Medina
- **Video demostración (10–15 minutos, acceso público):** https://www.youtube.com/watch?v=PFRz7pyi28k
